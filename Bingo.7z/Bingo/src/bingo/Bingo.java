/*
*/
package bingo;

public class Bingo {

    public static void main(String[] args) {
        int tabla[][] = new int[5][5];
        
        for(int i=0; i<tabla.length; i++){
            for(int j=0; j<tabla.length; j++){
                if(j==0)    tabla[i][j]=(int)(Math.random() *15+1);
                else if(j==1)    tabla[i][j]=(int)(Math.random() *15+15+1);
                else if(j==2)    tabla[i][j]=(int)(Math.random() *15+30+1);
                else if(j==3)    tabla[i][j]=(int)(Math.random() *15+45+1);
                else if(j==4)    tabla[i][j]=(int)(Math.random() *15+60+1);
            }
        }System.out.println("");
        
        System.out.println("\tB\tI\tN\tG\tO");       
        
        for(int i=0; i<tabla.length; i++){
            for(int j=0; j<tabla.length; j++){
                    System.out.print("\t"+tabla[i][j]);
            }
            System.out.println("");
        }
        
        
        
        
    }
    
}
